var a=function(e){return e.replace(/[A-Z]/g,function(r){return"-"+r.toLowerCase()}).toLowerCase()},n=a;export{n as c};
