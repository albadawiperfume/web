import{c as l}from"./@babel-ZjC2XTYG.js";var c={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/(function(i){(function(){var f={}.hasOwnProperty;function t(){for(var n=[],e=0;e<arguments.length;e++){var s=arguments[e];if(s){var o=typeof s;if(o==="string"||o==="number")n.push(s);else if(Array.isArray(s)){if(s.length){var a=t.apply(null,s);a&&n.push(a)}}else if(o==="object"){if(s.toString!==Object.prototype.toString&&!s.toString.toString().includes("[native code]")){n.push(s.toString());continue}for(var r in s)f.call(s,r)&&s[r]&&n.push(r)}}}return n.join(" ")}i.exports?(t.default=t,i.exports=t):window.classNames=t})()})(c);var p=c.exports;const m=l(p);export{m as a,p as c};
