import{r}from"./react-JXz1blL9.js";var a=r.useLayoutEffect;export{a as i};
